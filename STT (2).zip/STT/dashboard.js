document.getElementById('recorderLink').addEventListener('click', function(event) {
    event.preventDefault();
    document.getElementById('contentFrame').src = 'recorder.html';
    updateActiveLink(this);
});

document.getElementById('mainLink').addEventListener('click', function(event) {
    event.preventDefault();
    document.getElementById('contentFrame').src = 'main.html';
    updateActiveLink(this);
});

document.getElementById('profileLink').addEventListener('click', function(event) {
    event.preventDefault();
    document.getElementById('contentFrame').src = 'Update_Profile.html';
    updateActiveLink(this);
});

document.getElementById('historyLink').addEventListener('click', function(event) {
    event.preventDefault();
    document.getElementById('contentFrame').src = 'display_transcript.html';
    updateActiveLink(this);
});

function updateActiveLink(activeLink) {
    const links = document.querySelectorAll('.navbar-menu a');
    links.forEach(link => {
        link.classList.remove('active');
    });
    activeLink.classList.add('active');
}
