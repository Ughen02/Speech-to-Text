document.addEventListener('DOMContentLoaded', function() {

    let recordButton = document.getElementById('recordButton');
    let stopButton = document.getElementById('stopButton');
    let pauseButton = document.getElementById('pauseButton');
    let resumeButton = document.getElementById('resumeButton');
    let clearButton = document.getElementById('clearButton');
    let recordedaudioPlayback = document.getElementById('recordedaudioPlayback');
    let recordDownloadLink = document.getElementById('recordDownloadLink');

    let audioContext;
    let input;
    let recorder;
    let audioData = [];
    let isRecording = false;
    let isPaused = false;

    recordButton.addEventListener('click', startRecording);
    stopButton.addEventListener('click', stopRecording);
    pauseButton.addEventListener('click', pauseRecording);
    resumeButton.addEventListener('click', resumeRecording);
    clearButton.addEventListener('click', clearRecording);


    function startRecording() {
        audioData = [];
        navigator.mediaDevices.getUserMedia({ audio: true }).then(stream => {
            audioContext = new (window.AudioContext || window.webkitAudioContext)();
            input = audioContext.createMediaStreamSource(stream);
            recorder = audioContext.createScriptProcessor(4096, 1, 1);

            recorder.onaudioprocess = function (e) {
                if (!isRecording || isPaused) return;
                audioData.push(new Float32Array(e.inputBuffer.getChannelData(0)));
            };

            input.connect(recorder);
            recorder.connect(audioContext.destination);
            isRecording = true;
            isPaused = false;
            toggleButtons();
        });
    }

    function stopRecording() {
        if (!isRecording) return;
        isRecording = false;
        isPaused = false;
        recorder.disconnect();
        input.disconnect();

        let audioBlob = exportWAV(audioData);
        let audioUrl = URL.createObjectURL(audioBlob);
        recordedaudioPlayback.src = audioUrl;

        recordDownloadLink.href = audioUrl;
        recordDownloadLink.download = 'recording.wav';
        recordDownloadLink.style.display = 'block';

        toggleButtons();
    }

    function pauseRecording() {
        if (!isRecording || isPaused) return;
        isPaused = true;
        toggleButtons();
    }

    function resumeRecording() {
        if (!isRecording || !isPaused) return;
        isPaused = false;
        toggleButtons();
    }

    function clearRecording() {
        isRecording = false;
        isPaused = false;
        audioData = [];
        recordedaudioPlayback.src = '';
        recordDownloadLink.href = '';
        recordDownloadLink.style.display = 'none';
        toggleButtons();
    }

    function toggleButtons() {
        recordButton.disabled = isRecording || isPaused;
        stopButton.disabled = !isRecording;
        pauseButton.disabled = !isRecording || isPaused;
        resumeButton.disabled = !isRecording || !isPaused;
        clearButton.disabled = isRecording;

        
    }

    function exportWAV(audioData) {
        let bufferLength = audioData.reduce((acc, val) => acc + val.length, 0);
        let buffer = new Float32Array(bufferLength);
        let offset = 0;
        for (let i = 0; i < audioData.length; i++) {
            buffer.set(audioData[i], offset);
            offset += audioData[i].length;
        }

        let wavBuffer = encodeWAV(buffer, audioContext.sampleRate);
        return new Blob([wavBuffer], { type: 'audio/wav' });
    }

    function encodeWAV(samples, sampleRate) {
        let buffer = new ArrayBuffer(44 + samples.length * 2);
        let view = new DataView(buffer);

        function writeString(view, offset, string) {
            for (let i = 0; i < string.length; i++) {
                view.setUint8(offset + i, string.charCodeAt(i));
            }
        }

        writeString(view, 0, 'RIFF');
        view.setUint32(4, 36 + samples.length * 2, true);
        writeString(view, 8, 'WAVE');
        writeString(view, 12, 'fmt ');
        view.setUint32(16, 16, true);
        view.setUint16(20, 1, true);
        view.setUint16(22, 1, true);
        view.setUint32(24, sampleRate, true);
        view.setUint32(28, sampleRate * 2, true);
        view.setUint16(32, 2, true);
        view.setUint16(34, 16, true);
        writeString(view, 36, 'data');
        view.setUint32(40, samples.length * 2, true);

        let offset = 44;
        for (let i = 0; i < samples.length; i++, offset += 2) {
            let s = Math.max(-1, Math.min(1, samples[i]));
            view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7FFF, true);
        }

        return view;
    }
});
