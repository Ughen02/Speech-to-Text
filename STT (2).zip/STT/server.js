// Import the functions you need from the SDKs you need
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-auth.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-firestore.js";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCO-5DjXUL8P4Q5OmlsoMiOxkmzbTr0zRE",
  authDomain: "stt-users.firebaseapp.com",
  projectId: "stt-users",
  storageBucket: "stt-users.appspot.com",
  messagingSenderId: "183554783244",
  appId: "1:183554783244:web:06ae15f38a1f9e40e39629",
  measurementId: "G-TFYCT0P0BR"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

export { auth, db };

