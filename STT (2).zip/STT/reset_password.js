// reset_password.js
import { auth, db } from './server.js'; // Adjust the path if necessary
import { sendPasswordResetEmail } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-auth.js";
import { getDocs, collection, query, where } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-firestore.js";

document.getElementById('reset-password-form').addEventListener('submit', async (e) => {
    e.preventDefault();

    const email = document.getElementById('email').value;
    const messageElement = document.getElementById('message');

    // Check if the email exists in Firestore
    try {
        const q = query(collection(db, 'users'), where('email', '==', email));
        const querySnapshot = await getDocs(q);

        if (querySnapshot.empty) {
            messageElement.textContent = 'Error: Email not found in the database.';
            return;
        }

        // Email exists in Firestore, proceed with password reset
        await sendPasswordResetEmail(auth, email);
        messageElement.textContent = 'Password reset email sent! Check your inbox.';
    } catch (error) {
        messageElement.textContent = `Error: ${error.message}`;
    }
});
