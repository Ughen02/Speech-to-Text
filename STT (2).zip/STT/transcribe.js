import { auth, db } from './server.js';
import { onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-auth.js";
import { addDoc, collection } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-firestore.js";

document.addEventListener('DOMContentLoaded', function() {
    const uploadButton = document.getElementById('upload-button');
    const fileInput = document.getElementById('audio-upload');
    const outputDisplay = document.getElementById('outputDisplay');
    const transcribeButton = document.getElementById('transcribe-button');

    let formData = null;
    let currentUser = null;

    // Listen for auth state changes
    onAuthStateChanged(auth, (user) => {
        if (user) {
            currentUser = user;
        } else {
            window.location.href = 'login.html';
        }
    });

    uploadButton.addEventListener('click', () => {
        if (fileInput.files.length === 0) {
            alert('Please select a file');
            return;
        }

        formData = new FormData();
        formData.append('file', fileInput.files[0]);

        axios.post('http://127.0.0.1:8000/upload', formData, {
            headers: {
                'Content-Type': 'multipart/form-data'
            }
        })
        .then(function(response) {
            console.log(response);
        })
        .catch(function(error) {
            console.error('Error uploading file:', error);
            outputDisplay.textContent = 'Error uploading file. Please try again.';
        });
    });

    axios.get('http://127.0.0.1:8000/filename')
    .then(function(response) {
        if (response.status === 200) {
            const result = response.data;

            if (result.filename) {
                document.getElementById('uploadedFile').textContent = `File '${result.filename}' uploaded successfully. You can now transcribe.`;
                transcribeButton.disabled = false;
            } 
        } 
        else {
            console.error('Error fetching filename:', response.statusText);
            outputDisplay.textContent = 'Error fetching filename. Please try again.';
            transcribeButton.disabled = true;
        }
    })
    .catch(function(error) {
        console.error('Error:', error);
        outputDisplay.textContent = 'Error fetching filename. Please try again.';
        transcribeButton.disabled = true;
    });

    transcribeButton.addEventListener('click', function() {
        axios.get('http://127.0.0.1:8000/transcription')
        .then(async function(response) {
            if (response.status === 200) {
                const result = response.data;
                outputDisplay.textContent = result.transcription;

                // Store the transcription output in Firebase
                try {
                    if (currentUser) {
                        const docRef = await addDoc(collection(db, "transcriptions"), {
                            uid: currentUser.uid,
                            username: currentUser.displayName || currentUser.email,
                            transcription: result.transcription,
                            timestamp: new Date()
                        });
                        console.log("Document written with ID: ", docRef.id);
                    } else {
                        console.error("No user is currently signed in.");
                    }
                } catch (e) {
                    console.error("Error adding document: ", e);
                }
            } else {
                console.error('Error fetching transcription:', response.statusText);
                outputDisplay.textContent = 'Error fetching transcription. Please try again.';
            }
        })
        .catch(function(error) {
            console.error('Error:', error);
            outputDisplay.textContent = 'Error fetching transcription. Please try again.';
        });
    });
});
