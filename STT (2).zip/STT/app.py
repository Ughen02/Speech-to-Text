from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import librosa
import torch
from transformers import Wav2Vec2ForCTC, Wav2Vec2Tokenizer
import os
from deepmultilingualpunctuation import PunctuationModel
from transformers import AutoTokenizer, AutoModelForSeq2SeqLM
import re


app = FastAPI()

origins = [
    "http://127.0.0.1:8000",
    "http://127.0.0.1:5500",
    "http://127.0.0.1"
]

# Initialize CORS with the specified origins
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Load pre-trained model and tokenizer
tokenizer = Wav2Vec2Tokenizer.from_pretrained("facebook/wav2vec2-base-960h")
model = Wav2Vec2ForCTC.from_pretrained("facebook/wav2vec2-base-960h")

punctuationModel = PunctuationModel()

class GEC(object):
    def __init__(self, model, tokenizer):
        torch_device = 'cuda' if torch.cuda.is_available() else 'cpu'
        self.device = torch_device
        self.model = model.to(torch_device)
        self.tokenizer = tokenizer
        
    def correct(self, input):
        prefix = "grammar: "
        input = prefix + input
        input_ids = self.tokenizer(input, return_tensors="pt").input_ids.to(self.device)
        outputs = self.model.generate(input_ids, max_length=512, num_beams=5, early_stopping=True)
        cor = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
        return cor


grammar_model_path = "deobfuscator-v1"
grammar_tokenizer = AutoTokenizer.from_pretrained(grammar_model_path)
grammar_model = AutoModelForSeq2SeqLM.from_pretrained(grammar_model_path)

gec = GEC(grammar_model, grammar_tokenizer)


# class TranscriptionResponse(BaseModel):
#     transcription: str

# Global variable to store filename and transcription
file_transcription_data = {"filename": "", "transcription": ""}

# Function to format the text
def format_transcription(text):
    text = text.lower()  # Convert the entire text to lowercase
    if text:  # Check if the text is not empty
        text = text[0].upper() + text[1:]  # Capitalize the first letter
    return text

def capitalize_sentences(text):
    # Function to capitalize the first letter of each sentence
    def capitalize_first_letter(match):
        return match.group(1) + match.group(2).upper()

    # Ensure "i" is capitalized when it stands alone
    text = re.sub(r'\bi\b', 'I', text)

    # Capitalize the first letter after '.', '?', and '!'
    text = re.sub(r'([.?!]\s*)(\w)', capitalize_first_letter, text)

    # Capitalize the first letter of the text if it is not capitalized
    text = text[0].upper() + text[1:] if text else text

    return text


@app.post("/upload")
async def upload_file(file: UploadFile = File(...)):
    global file_transcription_data

    if file.content_type not in ["audio/mpeg", "audio/wav"]:
        raise HTTPException(status_code=400, detail="Invalid file type")

    try:
        # Ensure the 'audios' directory exists
        os.makedirs('audios', exist_ok=True)
        
        # Save the uploaded file
        file_path = os.path.join('audios', file.filename)
        with open(file_path, 'wb') as f:
            f.write(await file.read())

        # Load the audio file
        audio, sampling_rate = librosa.load(file_path, sr=16000)
        
        # Tokenize and predict
        input_values = tokenizer(audio, return_tensors='pt').input_values
        logits = model(input_values).logits
        predicted_ids = torch.argmax(logits, dim=-1)
        transcription = tokenizer.decode(predicted_ids[0])

        # Save filename and transcription to the global variable
        file_transcription_data = {
            "filename": file.filename,
            "transcription": format_transcription(transcription)
        }

        file_transcription_data["transcription"] = punctuationModel.restore_punctuation(file_transcription_data["transcription"])

        file_transcription_data["transcription"] = gec.correct(file_transcription_data["transcription"])

        file_transcription_data["transcription"] = capitalize_sentences(file_transcription_data["transcription"])


    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error processing audio file: {str(e)}")


@app.get("/transcription")
def get_transcription():
    return {"transcription": file_transcription_data["transcription"]}

@app.get("/filename")
def get_filename():
    return {"filename": file_transcription_data["filename"]}

