function encodeWAV(samples, sampleRate) {
    let buffer = new ArrayBuffer(44 + samples.length * 2);
    let view = new DataView(buffer);

    function writeString(view, offset, string) {
        for (let i = 0; i < string.length; i++) {
            view.setUint8(offset + i, string.charCodeAt(i));
        }
    }

    writeString(view, 0, 'RIFF');
    view.setUint32(4, 36 + samples.length * 2, true);
    writeString(view, 8, 'WAVE');
    writeString(view, 12, 'fmt ');
    view.setUint32(16, 16, true);
    view.setUint16(20, 1, true);
    view.setUint16(22, 1, true);
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, sampleRate * 2, true);
    view.setUint16(32, 2, true);
    view.setUint16(34, 16, true);
    writeString(view, 36, 'data');
    view.setUint32(40, samples.length * 2, true);

    let offset = 44;
    for (let i = 0; i < samples.length; i++, offset += 2) {
        let s = Math.max(-1, Math.min(1, samples[i]));
        view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7FFF, true);
    }

    return buffer;
}

document.getElementById('convertButton').addEventListener('click', function() {
    const fileInput = document.getElementById('videoInput');
    const file = fileInput.files[0];
    const loadingIndicator = document.getElementById('loadingIndicator');

    if (file) {
        loadingIndicator.style.display = 'block'; // Show loading indicator

        const url = URL.createObjectURL(file);
        const video = document.createElement('video');
        video.src = url;
        video.muted = false;  // Mute the video element

        video.addEventListener('loadedmetadata', () => {
            const audioContext = new (window.AudioContext || window.webkitAudioContext)();
            const source = audioContext.createMediaElementSource(video);
            const destination = audioContext.createMediaStreamDestination();

            source.connect(destination);
            source.connect(audioContext.destination);

            const audioChunks = [];
            const mediaRecorder = new MediaRecorder(destination.stream);

            mediaRecorder.ondataavailable = event => {
                if (event.data.size > 0) {
                    audioChunks.push(event.data);
                }
            };

            mediaRecorder.onstop = async () => {
                const audioBuffer = await new Response(new Blob(audioChunks)).arrayBuffer();
                const decodedAudioData = await audioContext.decodeAudioData(audioBuffer);
                const samples = decodedAudioData.getChannelData(0); // Assuming mono audio

                const wavBuffer = encodeWAV(samples, decodedAudioData.sampleRate);
                const audioBlob = new Blob([wavBuffer], { type: 'audio/wav' });
                const audioUrl = URL.createObjectURL(audioBlob);
                const audioPlayback = document.getElementById('audioPlayback');
                audioPlayback.src = audioUrl;

                const downloadLink = document.getElementById('downloadLink');
                downloadLink.href = audioUrl;
                downloadLink.download = 'audio.wav';
                downloadLink.style.display = 'block';

                loadingIndicator.style.display = 'none'; // Hide loading indicator
            };

            video.play();
            mediaRecorder.start();

            setTimeout(() => {
                mediaRecorder.stop();
                video.pause();
            }, video.duration * 1000); // Stop recording when video ends
        });
    } else {
        alert('Please select a video file.');
    }
});

